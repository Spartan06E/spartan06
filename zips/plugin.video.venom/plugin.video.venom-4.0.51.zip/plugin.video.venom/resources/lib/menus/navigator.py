# -*- coding: utf-8 -*-

"""
	# v4.0.51  Venom Lite  31-xx root-movies, tvshows, delete anime, tools-cf-lib-dl, 164 search
"""

import sys
from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import trakt

try:
	sysaddon = sys.argv[0]
	syshandle = int(sys.argv[1])
except:
	sysaddon = ''
	syshandle = '1'
	pass

artPath = control.artPath()
traktCredentials = trakt.getTraktCredentialsInfo()
traktIndicators = trakt.getTraktIndicatorsInfo()
imdbCredentials = control.setting('imdb.user') != ''
tmdbSessionID = control.setting('tmdb.session_id') != ''
indexLabels = control.setting('index.labels') == 'true'
iconLogos = control.setting('icon.logos') != 'Traditional'
notificationSound = control.setting('notification.sound') == 'true'


class Navigator:
	def root(self):
		self.addDirectoryItem("Movies", 'movieNavigator', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem("TV Shows", 'tvNavigator', 'tvshows.png', 'DefaultTVShows.png')
		self.addDirectoryItem("Search", 'searchNavigator', 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem("Settings", 'toolNavigator', 'tools.png', 'DefaultAddonService.png')
		self.addDirectoryItem("Tools", 'cfNavigator', 'tools.png', 'DefaultAddonService.png')

		downloads = True if control.setting('downloads') == 'true' and (len(control.listDir(control.setting('movie.download.path'))[0]) > 0 or len(control.listDir(control.setting('tv.download.path'))[0]) > 0) else False
		if downloads:
			self.addDirectoryItem("Downloads", 'downloadNavigator', 'downloads.png', 'DefaultFolder.png')
		if control.getMenuEnabled('navi.changelog'):
			self.addDirectoryItem("Version Info", 'ShowChangelog', 'icon.png', 'DefaultAddonsUpdates.png', isFolder=False)
		self.endDirectory()


	def movies(self, lite=False):
		self.addDirectoryItem("Top Watched Movies of The Week (Trakt)", 'movies&url=traktweekly', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem("Trending (Trakt)", 'movies&url=trakttrending', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem("Recently Added Movies (IMDb)", 'newMovies', 'movies.png', 'DefaultRecentlyAddedMovies.png')
		self.addDirectoryItem("Featured (IMDb)", 'movies&url=featured', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem("Most Popular (IMDb)", 'movies&url=mostpopular', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem("Genres (IMDb)", 'movieGenres', 'movies.png', 'DefaultGenre.png')
		self.addDirectoryItem("Year (IMDb)", 'movieYears', 'movies.png', 'DefaultYear.png')
		self.addDirectoryItem("People (IMDb)", 'moviePersons', 'movies.png', 'DefaultActor.png')
		self.addDirectoryItem("Languages (IMDb)", 'movieLanguages', 'movies.png', 'DefaultAddonLanguage.png')

		if not lite:
			if control.getMenuEnabled('mylists.widget'):
				self.addDirectoryItem("My Movie Lists (Trakt User)", 'movieUserlists', 'mymovies.png', 'DefaultVideoPlaylists.png')

			self.addDirectoryItem("People Search (Movies)", 'moviePerson', 'people-search.png', 'DefaultAddonsSearch.png')
			self.addDirectoryItem("Search", 'movieSearch', 'search.png', 'DefaultAddonsSearch.png')
		self.endDirectory()


	def tvshows(self, lite=False):
		self.addDirectoryItem("Trending (Trakt)", 'tvshows&url=trakttrending', 'tvshows.png', 'DefaultTVShows.png')
		self.addDirectoryItem("Most Popular (Trakt)", 'tvshows&url=traktpopular', 'tvshows.png', 'DefaultTVShows.png', queue=True)
		self.addDirectoryItem("Most Popular (IMDb)", 'tvshows&url=popular', 'tvshows.png', 'DefaultTVShows.png')
		self.addDirectoryItem("Returning TV Shows (IMDb)", 'tvshows&url=active', 'tvshows.png', 'DefaultRecentlyAddedEpisodes.png')
		self.addDirectoryItem("New TV Shows (IMDb)", 'tvshows&url=premiere', 'tvshows.png', 'DefaultRecentlyAddedEpisodes.png')
		self.addDirectoryItem("Networks (TVMaze)", 'tvNetworks', 'networks.png', 'DefaultNetwork.png')
		self.addDirectoryItem("Genres (IMDb)", 'tvGenres', 'tvshows.png', 'DefaultGenre.png')
		self.addDirectoryItem("Languages (IMDb)", 'tvLanguages', 'tvshows.png', 'DefaultAddonLanguage.png')
		self.addDirectoryItem("Calendar (TVMaze)", 'calendars', 'tvshows.png', 'DefaultYear.png')

		if not lite:
			if control.getMenuEnabled('mylists.widget'):
				self.addDirectoryItem("My TV Show Lists (Trakt User)", 'tvUserlists', 'mytvshows.png', 'DefaultVideoPlaylists.png')

			self.addDirectoryItem("People Search (TV)", 'tvPerson', 'people-search.png', 'DefaultAddonsSearch.png')
			self.addDirectoryItem("Search", 'tvSearch', 'search.png', 'DefaultAddonsSearch.png')
		self.endDirectory()


	def tools(self):
		#-- General - 0
		self.addDirectoryItem("[COLOR lawngreen]Venom Settings[/COLOR]", 'openSettings&query=0.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		#-- Providers - 4
		self.addDirectoryItem("[COLOR lawngreen]OpenScrapers Settings[/COLOR]", 'openscrapersSettings', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]ResolveURL Settings[/COLOR]", 'urlResolver', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Real-Debrid Settings[/COLOR]", 'urlResolverRDTorrent&query=1.53', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Authorize Trakt[/COLOR]", 'authTrakt&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		#-- Subtitles - 11
		self.addDirectoryItem("[COLOR lawngreen]Subtitle Settings[/COLOR]", 'openSettings&query=11.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Manage Library[/COLOR]", 'libraryNavigator', 'tools.png', 'DefaultAddonService.png', isFolder=True)
		if control.condVisibility('System.HasAddon(service.upnext)'):
			self.addDirectoryItem("[COLOR lawngreen]UpNext Settings[/COLOR]", 'UpNextSettings', 'UpNext.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Set View Types[/COLOR]", 'viewsNavigator', 'tools.png', 'DefaultAddonService.png', isFolder=True)
		self.endDirectory()


	def cf(self):
		self.addDirectoryItem("[COLOR lawngreen]Clear Venom Cache[/COLOR]", 'clearCache&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Clear OpenScrapers Cache[/COLOR]", 'clearSources&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Clear Metadata Cache[/COLOR]", 'clearMetaCache&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Clear Search Cache[/COLOR]", 'clearCacheSearch&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Clear Bookmarks Cache[/COLOR]", 'clearBookmarks&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR red]Clear All Venom Caches[/COLOR]", 'clearAllCache&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Clear ResolveURL Cache[/COLOR]", 'clearResolveURLcache', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Clean Settings[/COLOR]", 'cleanSettings', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Clean library[/COLOR]", 'cleanLibrary', 'tools.png', 'DefaultAddonLibrary.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Reset View Types[/COLOR]", 'resetViewTypes', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()


	def library(self):
	# -- Library - 9
		self.addDirectoryItem("Library Settings", 'openSettings&query=9.0', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem("Update library", 'updateLibrary', 'library_update.png', 'DefaultAddonLibrary.png', isFolder=False)
		self.addDirectoryItem("Clean library", 'cleanLibrary', 'library_update.png', 'DefaultAddonLibrary.png', isFolder=False)
		self.addDirectoryItem("Movie folder", control.setting('library.movie'), 'movies.png', 'DefaultMovies.png', isAction=False)
		self.addDirectoryItem("TV folder", control.setting('library.tv'), 'tvshows.png', 'DefaultTVShows.png', isAction=False)

		if traktCredentials:
			self.addDirectoryItem("[B]TRAKT[/B] : Import Movie Collection...", 'moviesToLibrary&url=traktcollection&list_name=traktcollection', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem("[B]TRAKT[/B] : Import Movie Watchlist...", 'moviesToLibrary&url=traktwatchlist&list_name=traktwatchlist', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem("[B]TRAKT[/B] : Import Movie User List...", 'moviesListToLibrary&url=traktlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem("[B]TRAKT[/B] : Import Movie Liked List...", 'moviesListToLibrary&url=traktlikedlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)

		if tmdbSessionID:
			self.addDirectoryItem('TMDb: Import Movie Watchlist...', 'moviesToLibrary&url=tmdb_watchlist&list_name=tmdb_watchlist', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import Movie Favorites...', 'moviesToLibrary&url=tmdb_favorites&list_name=tmdb_favorites', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import Movie User list...', 'moviesListToLibrary&url=tmdb_userlists', 'tmdb.png', 'DefaultMovies.png', isFolder=False)

		if traktCredentials:
			self.addDirectoryItem("[B]TRAKT[/B] : Import TV Collection...", 'tvshowsToLibrary&url=traktcollection&list_name=traktcollection', 'trakt.png', 'DefaultTVShows.png', isFolder=False)
			self.addDirectoryItem("[B]TRAKT[/B] : Import TV Watchlist...", 'tvshowsToLibrary&url=traktwatchlist&list_name=traktwatchlist', 'trakt.png', 'DefaultTVShows.png', isFolder=False)
			self.addDirectoryItem("[B]TRAKT[/B] : Import TV User List...", 'tvshowsListToLibrary&url=traktlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem("[B]TRAKT[/B] : Import TV Liked List...", 'tvshowsListToLibrary&url=traktlikedlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)

		if tmdbSessionID:
			self.addDirectoryItem('TMDb: Import TV Watchlist...', 'tvshowsToLibrary&url=tmdb_watchlist&list_name=tmdb_watchlist', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import TV Favorites...', 'tvshowsToLibrary&url=tmdb_favorites&list_name=tmdb_favorites', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import TV User list...', 'tvshowsListToLibrary&url=tmdb_userlists', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
		self.endDirectory()


	def downloads(self):
		movie_downloads = control.setting('movie.download.path')
		tv_downloads = control.setting('tv.download.path')
		if len(control.listDir(movie_downloads)[0]) > 0:
			self.addDirectoryItem("Movies", movie_downloads, 'movies.png', 'DefaultMovies.png', isAction=False)
		if len(control.listDir(tv_downloads)[0]) > 0:
			self.addDirectoryItem("TV Shows", tv_downloads, 'tvshows.png', 'DefaultTVShows.png', isAction=False)
		self.endDirectory()


	def search(self):
		self.addDirectoryItem("Movies", 'movieSearch', 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem("TV Shows", 'tvSearch', 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem("People Search (Movies)", 'moviePerson', 'people-search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem("People Search (TV)", 'tvPerson', 'people-search.png', 'DefaultAddonsSearch.png')
		self.endDirectory()


	def views(self):
		try:
			control.hide()
			items = [ (control.lang(32001).encode('utf-8'), 'movies'), (control.lang(32002).encode('utf-8'), 'tvshows'),
							(control.lang(32054).encode('utf-8'), 'seasons'), (control.lang(32038).encode('utf-8'), 'episodes') ]
			select = control.selectDialog([i[0] for i in items], control.lang(32049).encode('utf-8'))
			if select == -1:
				return
			content = items[select][1]
			title = control.lang(32059).encode('utf-8')
			url = '%s?action=addView&content=%s' % (sys.argv[0], content)
			poster, banner, fanart = control.addonPoster(), control.addonBanner(), control.addonFanart()
			item = control.item(label=title)
			item.setInfo(type='video', infoLabels = {'title': title})
			item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': fanart, 'banner': banner})
			item.setProperty('IsPlayable', 'false')
			control.addItem(handle = int(sys.argv[1]), url=url, listitem=item, isFolder=False)
			control.content(int(sys.argv[1]), content)
			control.directory(int(sys.argv[1]), cacheToDisc=True)
			from resources.lib.modules import views
			views.setView(content, {})
		except:
			log_utils.error()
			return


	def accountCheck(self):
		if not traktCredentials and not imdbCredentials:
			control.hide()
			control.notification(title='default', message=32042, icon='WARNING', sound=notificationSound)
			sys.exit()


	def infoCheck(self, version):
		try:
			control.notification(title='default', message=32074, icon='WARNING',  time=5000, sound=notificationSound)
			return '1'
		except:
			return '1'


	def clearCacheAll(self):
		control.hide()
		yes = control.yesnoDialog(control.lang(32077).encode('utf-8'), '', '')
		if not yes:
			return
		try:
			from resources.lib.modules import cache
			cache.cache_clear_all()
			control.notification(title='default', message='All Cache Successfully Cleared!', icon='default', sound=notificationSound)
		except:
			log_utils.error()
			pass


	def clearCacheProviders(self):
		control.hide()
		yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
		if not yes:
			return
		try:
			from resources.lib.modules import cache
			cache.cache_clear_providers()
			control.notification(title='default', message='Provider Cache Successfully Cleared!', icon='default', sound=notificationSound)
		except:
			log_utils.error()
			pass


	def clearCacheMeta(self):
		control.hide()
		yes = control.yesnoDialog(control.lang(32076).encode('utf-8'), '', '')
		if not yes:
			return
		try:
			from resources.lib.modules import cache
			cache.cache_clear_meta()
			control.notification(title='default', message='Metadata Cache Successfully Cleared!', icon='default', sound=notificationSound)
		except:
			log_utils.error()
			pass


	def clearCache(self):
		control.hide()
		yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
		if not yes:
			return
		try:
			from resources.lib.modules import cache
			cache.cache_clear()
			control.notification(title='default', message='Cache Successfully Cleared!', icon='default', sound=notificationSound)
		except:
			log_utils.error()
			pass


	def clearCacheSearch(self):
		control.hide()
		yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
		if not yes:
			return
		try:
			from resources.lib.modules import cache
			cache.cache_clear_search()
			control.notification(title='default', message='Search History Successfully Cleared!', icon='default', sound=notificationSound)
		except:
			log_utils.error()
			pass


	def clearCacheSearchPhrase(self, table, name):
		control.hide()
		yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
		if not yes:
			return
		try:
			from resources.lib.modules import cache
			cache.cache_clear_SearchPhrase(table, name)
			control.notification(title='default', message='Search Phrase Successfully Cleared!', icon='default', sound=notificationSound)
		except:
			log_utils.error()
			pass


	def clearBookmarks(self):
		control.hide()
		yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
		if not yes:
			return
		try:
			from resources.lib.modules import cache
			cache.cache_clear_bookmarks()
			control.notification(title='default', message='Bookmarks Successfully Cleared!', icon='default', sound=notificationSound)
		except:
			log_utils.error()
			pass


	def clearBookmark(self, name, year):
		control.hide()
		yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
		if not yes:
			return
		try:
			from resources.lib.modules import cache
			cache.cache_clear_bookmark(name, year)
			control.notification(title=name, message='Bookmark Successfully Cleared!', icon='default', sound=notificationSound)
		except:
			log_utils.error()
			pass


	def addDirectoryItem(self, name, query, thumb, icon, context=None, queue=False, isAction=True, isFolder=True, isPlayable=False, isSearch=False, table=''):
		try:
			if type(name) is str or type(name) is unicode:
				name = str(name)
			if type(name) is int:
				name = control.lang(name).encode('utf-8')
		except:
			log_utils.error()
		url = '%s?action=%s' % (sysaddon, query) if isAction else query
		thumb = control.joinPath(artPath, thumb) if artPath else icon
		if not icon.startswith('Default'):
			icon = control.joinPath(artPath, icon)
		cm = []
		queueMenu = control.lang(32065).encode('utf-8')
		if queue:
			cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))
		if context:
			cm.append((control.lang(context[0]).encode('utf-8'), 'RunPlugin(%s?action=%s)' % (sysaddon, context[1])))
		if isSearch:
			try:
				from urllib import quote_plus
			except:
				from urllib.parse import quote_plus
			cm.append(('Clear Search Phrase', 'RunPlugin(%s?action=clearSearchPhrase&table=%s&name=%s)' % (sysaddon, table, quote_plus(name))))
		# cm.append((control.lang(32610).encode('utf-8'), 'RunPlugin(%s?action=clearAllCache&opensettings=false)' % sysaddon))
		cm.append(('[COLOR red]Venom Settings[/COLOR]', 'RunPlugin(%s?action=openSettings)' % sysaddon))
		item = control.item(label=name)
		item.addContextMenuItems(cm)
		if isPlayable:
			item.setProperty('IsPlayable', 'true')
		else:
			item.setProperty('IsPlayable', 'false')
		item.setArt({'icon': icon, 'poster': thumb, 'thumb': thumb, 'fanart': control.addonFanart(), 'banner': thumb})
		control.addItem(handle=syshandle, url=url, listitem=item, isFolder= isFolder)


	def endDirectory(self):
		control.content(syshandle, 'addons')
		control.directory(syshandle, cacheToDisc=True)