# -*- coding: utf-8 -*-
"""
	Venom Add-on 5031
"""

from sys import argv, exit as sysexit
from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import trakt
try: #Py2
	from urllib import quote_plus
except ImportError:  #Py3
	from urllib.parse import quote_plus

artPath = control.artPath()
traktCredentials = trakt.getTraktCredentialsInfo()
traktIndicators = trakt.getTraktIndicatorsInfo()
imdbCredentials = control.setting('imdb.user') != ''
tmdbSessionID = control.setting('tmdb.session_id') != ''
indexLabels = control.setting('index.labels') == 'true'
iconLogos = control.setting('icon.logos') != 'Traditional'


class Navigator:
	def root(self):
		self.addDirectoryItem('Movies', 'movieNavigator', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem('TV Shows', 'tvNavigator', 'tvshows.png', 'DefaultTVShows.png')		
		self.addDirectoryItem('Real-Debrid', 'rd_ServiceNavigator', 'realdebrid.png', 'DefaultAddonService.png')
		self.addDirectoryItem('Search', 'tools_searchNavigator', 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem('Settings', 'tools_toolNavigator', 'settings.png', 'DefaultAddonService.png')
		self.addDirectoryItem('Tools', 'cache_Navigator', 'tools.png', 'DefaultAddonService.png')
		self.endDirectory()

	def movies(self, lite=False):
		self.addDirectoryItem('In Theaters', 'movies&url=theaters', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem('Featured', 'movies&url=featured', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem('Now Playing', 'tmdbmovies&url=tmdb_nowplaying', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem('Trending', 'movies&url=trakttrending', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem('Movie Categories', 'movieGenres', 'movies.png', 'DefaultGenre.png')
		self.addDirectoryItem('Search Movies By Actor', 'moviePerson', 'search_movies_people.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem('Search Movies', 'movieSearch', 'search_movie.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def tvshows(self, lite=False):
		self.addDirectoryItem('New TV Shows', 'tvshows&url=premiere', 'tvshows.png', 'DefaultRecentlyAddedEpisodes.png')
		self.addDirectoryItem('Current TV Shows', 'tvshows&url=active', 'tvshows.png', 'DefaultRecentlyAddedEpisodes.png')
		self.addDirectoryItem('Networks', 'tvNetworks', 'tvshows.png', 'DefaultNetwork.png')
		self.addDirectoryItem('Amazon Hulu Netflix', 'tvOriginals', 'tvshows.png', 'DefaultNetwork.png')
		self.addDirectoryItem('IMDb.com', 'tvshows&url=popular', 'tvshows.png', 'DefaultTVShows.png')
		self.addDirectoryItem('Trakt.tv', 'tvshows&url=traktpopular', 'tvshows.png', 'DefaultTVShows.png', queue=True)
		self.addDirectoryItem('TMDb.org', 'tmdbTvshows&url=tmdb_popular', 'tvshows.png', 'DefaultTVShows.png')
		self.addDirectoryItem('TV Show Categories', 'tvGenres', 'tvshows.png', 'DefaultGenre.png')
		self.addDirectoryItem('Search TV Shows By Actor', 'tvPerson', 'search_tv_shows_people.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem('Search TV Shows', 'tvSearch', 'search_tv.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def tools(self):
		self.addDirectoryItem('Venom Settings', 'tools_openSettings&query=0.0', 'settings.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem('FenomScrapers Settings', 'tools_fenomscrapersSettings', 'settings.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem('My Accounts Settings', 'tools_openMyAccount', 'settings.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem('Subtitle Settings', 'tools_openSettings&query=10.0', 'settings.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem('Manage Library', 'library_Navigator', 'settings.png', 'DefaultAddonService.png', isFolder=True)
		self.addDirectoryItem('Set View Types', 'tools_viewsNavigator', 'settings.png', 'DefaultAddonService.png', isFolder=True)
		self.addDirectoryItem('Venom Update Info', 'tools_ShowChangelog', 'settings.png', 'DefaultAddonsUpdates.png', isFolder=False)
		downloads = True if control.setting('downloads') == 'true' and (len(control.listDir(control.setting('movie.download.path'))[0]) > 0 or len(control.listDir(control.setting('tv.download.path'))[0]) > 0) else False
		if downloads: self.addDirectoryItem(32009, 'downloadNavigator', 'downloads.png', 'DefaultFolder.png')
		self.endDirectory()

	def cf(self):
		self.addDirectoryItem('Clear Cache', 'cache_clearCache', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem('Clear Scrapers Cache', 'cache_clearSources', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem('Clear Metadata Cache', 'cache_clearMeta', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem('Clear Search Cache', 'cache_clearSearch', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem('Clear Bookmarks Cache', 'cache_clearBookmarks', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem('Clear ALL Cache', 'cache_clearAll', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem('Clean Settings', 'tools_cleanSettings', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem('Reset View Types', 'tools_resetViewTypes', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()

	def search(self):
		self.addDirectoryItem('Search Movies', 'movieSearch', 'search_movie.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem('Search TV Shows', 'tvSearch', 'search_tv.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem('Search Movies By Actor', 'moviePerson', 'search_movies_people', 'DefaultAddonsSearch.png')
		self.addDirectoryItem('Search TV Shows By Actor', 'tvPerson', 'search_tv_shows_people.png', 'DefaultAddonsSearch.png')
		self.endDirectory()

	def library(self):
	# -- Library - 8
		self.addDirectoryItem(32557, 'tools_openSettings&query=8.0', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem(32558, 'library_update', 'library_update.png', 'DefaultAddonLibrary.png', isFolder=False)
		self.addDirectoryItem(32676, 'library_clean', 'library_update.png', 'DefaultAddonLibrary.png', isFolder=False)
		self.addDirectoryItem(32559, control.setting('library.movie'), 'movies.png', 'DefaultMovies.png', isAction=False)
		self.addDirectoryItem(32560, control.setting('library.tv'), 'tvshows.png', 'DefaultTVShows.png', isAction=False)
		if traktCredentials:
			self.addDirectoryItem(32561, 'library_moviesToLibrary&url=traktcollection&name=traktcollection', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32562, 'library_moviesToLibrary&url=traktwatchlist&name=traktwatchlist', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32672, 'library_moviesListToLibrary&url=traktlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32673, 'library_moviesListToLibrary&url=traktlikedlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
		if tmdbSessionID:
			self.addDirectoryItem('TMDb: Import Movie Watchlist...', 'library_moviesToLibrary&url=tmdb_watchlist&name=tmdb_watchlist', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import Movie Favorites...', 'library_moviesToLibrary&url=tmdb_favorites&name=tmdb_favorites', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import Movie User list...', 'library_moviesListToLibrary&url=tmdb_userlists', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
		if traktCredentials:
			self.addDirectoryItem(32563, 'library_tvshowsToLibrary&url=traktcollection&name=traktcollection', 'trakt.png', 'DefaultTVShows.png', isFolder=False)
			self.addDirectoryItem(32564, 'library_tvshowsToLibrary&url=traktwatchlist&name=traktwatchlist', 'trakt.png', 'DefaultTVShows.png', isFolder=False)
			self.addDirectoryItem(32674, 'library_tvshowsListToLibrary&url=traktlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32675, 'library_tvshowsListToLibrary&url=traktlikedlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
		if tmdbSessionID:
			self.addDirectoryItem('TMDb: Import TV Watchlist...', 'library_tvshowsToLibrary&url=tmdb_watchlist&name=tmdb_watchlist', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import TV Favorites...', 'library_tvshowsToLibrary&url=tmdb_favorites&name=tmdb_favorites', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import TV User list...', 'library_tvshowsListToLibrary&url=tmdb_userlists', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
		self.endDirectory()

	def downloads(self):
		movie_downloads = control.setting('movie.download.path')
		tv_downloads = control.setting('tv.download.path')
		if len(control.listDir(movie_downloads)[0]) > 0: self.addDirectoryItem(32001, movie_downloads, 'movies.png', 'DefaultMovies.png', isAction=False)
		if len(control.listDir(tv_downloads)[0]) > 0: self.addDirectoryItem(32002, tv_downloads, 'tvshows.png', 'DefaultTVShows.png', isAction=False)
		self.endDirectory()

	def premium_services(self):
		self.addDirectoryItem(40059, 'ad_ServiceNavigator', 'alldebrid.png', 'DefaultAddonService.png')
		self.addDirectoryItem(40057, 'pm_ServiceNavigator', 'premiumize.png', 'DefaultAddonService.png')
		self.addDirectoryItem(40058, 'rd_ServiceNavigator', 'realdebrid.png', 'DefaultAddonService.png')
		self.endDirectory()

	def alldebrid_service(self):
		if control.setting('alldebrid.token'):
			self.addDirectoryItem('All-Debrid: Cloud Storage', 'ad_CloudStorage', 'alldebrid.png', 'DefaultAddonService.png')
			self.addDirectoryItem('All-Debrid: Transfers', 'ad_Transfers', 'alldebrid.png', 'DefaultAddonService.png')
			self.addDirectoryItem('All-Debrid: Account Info', 'ad_AccountInfo', 'alldebrid.png', 'DefaultAddonService.png', isFolder=False)
		else:
			self.addDirectoryItem('[I]Please visit My Accounts for setup[/I]', 'tools_openMyAccount&amp;query=1.4', 'alldebrid.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()

	def premiumize_service(self):
		if control.setting('premiumize.token'):
			self.addDirectoryItem('Premiumize: My Files', 'pm_MyFiles', 'premiumize.png', 'DefaultAddonService.png')
			self.addDirectoryItem('Premiumize: Transfers', 'pm_Transfers', 'premiumize.png', 'DefaultAddonService.png')
			self.addDirectoryItem('Premiumize: Account Info', 'pm_AccountInfo', 'premiumize.png', 'DefaultAddonService.png', isFolder=False)
		else:
			self.addDirectoryItem('[I]Please visit My Accounts for setup[/I]', 'tools_openMyAccount&amp;query=1.11', 'premiumize.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()

	def realdebrid_service(self):
		if control.setting('realdebrid.token'):
			self.addDirectoryItem('Real-Debrid: Torrent Transfers', 'rd_UserTorrentsToListItem', 'realdebrid.png', 'DefaultAddonService.png')
			self.addDirectoryItem('Real-Debrid: My Downloads', 'rd_MyDownloads&query=1', 'realdebrid.png', 'DefaultAddonService.png')
			self.addDirectoryItem('Real-Debrid: Account Info', 'rd_AccountInfo', 'realdebrid.png', 'DefaultAddonService.png',isFolder=False )
		else:
			self.addDirectoryItem('[I]Please visit My Accounts for setup[/I]', 'tools_openMyAccount&amp;query=1.18', 'realdebrid.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()

	def views(self):
		try:
			syshandle = int(argv[1])
			control.hide()
			items = [(control.lang(32001), 'movies'), (control.lang(32002), 'tvshows'), (control.lang(32054), 'seasons'), (control.lang(32038), 'episodes') ]
			select = control.selectDialog([i[0] for i in items], control.lang(32049))
			if select == -1: return
			content = items[select][1]
			title = control.lang(32059)
			url = '%s?action=tools_addView&content=%s' % (argv[0], content)
			poster, banner, fanart = control.addonPoster(), control.addonBanner(), control.addonFanart()
			try: item = control.item(label=title, offscreen=True)
			except: item = control.item(label=title)
			item.setInfo(type='video', infoLabels = {'title': title})
			item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': fanart, 'banner': banner})
			item.setProperty('IsPlayable', 'false')
			control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
			control.content(syshandle, content)
			control.directory(syshandle, cacheToDisc=True)
			from resources.lib.modules import views
			views.setView(content, {})
		except:
			log_utils.error()
			return

	def accountCheck(self):
		if not traktCredentials and not imdbCredentials:
			control.hide()
			control.notification(message=32042, icon='WARNING')
			sysexit()

	def clearCacheAll(self):
		control.hide()
		if not control.yesnoDialog(control.lang(32077), '', ''): return
		try:
			def cache_clear_all():
				try:
					from resources.lib.database import cache, providerscache, metacache
					providerscache.cache_clear_providers()
					metacache.cache_clear_meta()
					cache.cache_clear()
					cache.cache_clear_search()
					cache.cache_clear_bookmarks()
					return True
				except:
					log_utils.error()
			if cache_clear_all():
				control.notification(message=32089)
			else: control.notification(message=33586)
		except:
			log_utils.error()

	def clearCacheProviders(self):
		control.hide()
		if not control.yesnoDialog(control.lang(32056), '', ''): return
		try:
			from resources.lib.database import providerscache
			if providerscache.cache_clear_providers(): control.notification(message=32090)
			else: control.notification(message=33586)
		except:
			log_utils.error()

	def clearCacheMeta(self):
		control.hide()
		if not control.yesnoDialog(control.lang(32076), '', ''): return
		try:
			from resources.lib.database import metacache
			if metacache.cache_clear_meta(): control.notification(message=32091)
			else: control.notification(message=33586)
		except:
			log_utils.error()

	def clearCache(self):
		control.hide()
		if not control.yesnoDialog(control.lang(32056), '', ''): return
		try:
			from resources.lib.database import cache
			if cache.cache_clear(): control.notification(message=32092)
			else: control.notification(message=33586)
		except:
			log_utils.error()

	def clearCacheSearch(self):
		control.hide()
		if not control.yesnoDialog(control.lang(32056), '', ''): return
		try:
			from resources.lib.database import cache
			if cache.cache_clear_search(): control.notification(message=32093)
			else: control.notification(message=33586)
		except:
			log_utils.error()

	def clearCacheSearchPhrase(self, table, name):
		control.hide()
		if not control.yesnoDialog(control.lang(32056), '', ''): return
		try:
			from resources.lib.database import cache
			if cache.cache_clear_SearchPhrase(table, name): control.notification(message=32094)
			else: control.notification(message=33586)
		except:
			log_utils.error()

	def clearBookmarks(self):
		control.hide()
		if not control.yesnoDialog(control.lang(32056), '', ''): return
		try:
			from resources.lib.database import cache
			if cache.cache_clear_bookmarks(): control.notification(message=32100)
			else: control.notification(message=33586)
		except:
			log_utils.error()

	def clearBookmark(self, name, year):
		control.hide()
		if not control.yesnoDialog(control.lang(32056), '', ''): return
		try:
			from resources.lib.database import cache
			if cache.cache_clear_bookmark(name, year): control.notification(title=name, message=32102)
			else: control.notification(message=33586)
		except:
			log_utils.error()

	def addDirectoryItem(self, name, query, thumb, icon, context=None, queue=False, isAction=True, isFolder=True, isPlayable=False, isSearch=False, table=''):
		sysaddon = argv[0] ; syshandle = int(argv[1])
		try:
			if isinstance(name, int): name = control.lang(name)
		except:
			log_utils.error()
		url = '%s?action=%s' % (sysaddon, query) if isAction else query
		thumb = control.joinPath(artPath, thumb) if artPath else icon
		if not icon.startswith('Default'): icon = control.joinPath(artPath, icon)
		cm = []
		queueMenu = control.lang(32065)
		if queue: cm.append((queueMenu, 'RunPlugin(%s?action=playlist_QueueItem)' % sysaddon))
		if context: cm.append((control.lang(context[0]), 'RunPlugin(%s?action=%s)' % (sysaddon, context[1])))
		if isSearch: cm.append(('Clear Search Phrase', 'RunPlugin(%s?action=cache_clearSearchPhrase&source=%s&name=%s)' % (sysaddon, table, quote_plus(name))))
		cm.append(('[COLOR red]Venom Settings[/COLOR]', 'RunPlugin(%s?action=tools_openSettings)' % sysaddon))
		try: item = control.item(label=name, offscreen=True)
		except: item = control.item(label=name)
		item.addContextMenuItems(cm)
		if isPlayable: item.setProperty('IsPlayable', 'true')
		else: item.setProperty('IsPlayable', 'false')
		item.setArt({'icon': icon, 'poster': thumb, 'thumb': thumb, 'fanart': control.addonFanart(), 'banner': thumb})
		control.addItem(handle=syshandle, url=url, listitem=item, isFolder= isFolder)

	def endDirectory(self):
		syshandle = int(argv[1])
		control.content(syshandle, 'addons')
		control.directory(syshandle, cacheToDisc=True)