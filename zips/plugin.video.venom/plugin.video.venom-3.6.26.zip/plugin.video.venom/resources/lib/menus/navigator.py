# -*- coding: utf-8 -*-

'''
	# v362.5  Lite  26-27 labels-logos removed, 30-xx root-movies, tvshows, delete anime, add settings-cf-lib, 164 search
'''

import os, sys

from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import trakt

try:
	sysaddon = sys.argv[0]
	syshandle = int(sys.argv[1])
except:
	sysaddon = ''
	syshandle = '1'
	pass

artPath = control.artPath()
imdbCredentials = False if control.setting('imdb.user') == '' else True
tmdbSessionID = False if control.setting('tmdb.session_id') == '' else True
traktCredentials = trakt.getTraktCredentialsInfo()
traktIndicators = trakt.getTraktIndicatorsInfo()
notificationSound = False if control.setting('notification.sound') == 'false' else True


class Navigator:
	def root(self):
		self.addDirectoryItem(32001, 'movieNavigator', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem(32002, 'tvNavigator', 'tvshows.png', 'DefaultTVShows.png')
		self.addDirectoryItem(32010, 'searchNavigator', 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(60028, 'settingsNavigator', 'tools.png', 'DefaultAddonService.png')
		self.addDirectoryItem(32008, 'toolNavigator', 'tools.png', 'DefaultAddonService.png')

		downloads = True if control.setting('downloads') == 'true' and (len(control.listDir(control.setting('movie.download.path'))[0]) > 0 or len(control.listDir(control.setting('tv.download.path'))[0]) > 0) else False
		if downloads is True:
			self.addDirectoryItem(32009, 'downloadNavigator', 'downloads.png', 'DefaultFolder.png')
		self.endDirectory()


	def movies(self, lite=False):
		self.addDirectoryItem(62677, 'movies&url=traktweekly', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem(60020, 'newMovies', 'movies.png', 'DefaultRecentlyAddedMovies.png')
		self.addDirectoryItem(32447, 'movies&url=featured', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem(32429, 'movies&url=mostpopular', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem(32443, 'movies&url=trakttrending', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem(32456, 'movieGenres', 'movies.png', 'DefaultGenre.png')
		self.addDirectoryItem(32458, 'movieYears', 'movies.png', 'DefaultYear.png')
		self.addDirectoryItem(32460, 'moviePersons', 'movies.png', 'DefaultActor.png')
		self.addDirectoryItem(32462, 'movieLanguages', 'movies.png', 'DefaultAddonLanguage.png')

		if lite is False:
			if control.getMenuEnabled('mylists.widget'):
				self.addDirectoryItem(60046, 'movieUserlists', 'mymovies.png', 'DefaultVideoPlaylists.png')

			self.addDirectoryItem(62029, 'moviePerson', 'people-search.png', 'DefaultAddonsSearch.png')
			self.addDirectoryItem(32010, 'movieSearch', 'search.png', 'DefaultAddonsSearch.png')
		self.endDirectory()


	def tvshows(self, lite=False):
		self.addDirectoryItem(32443, 'tvshows&url=trakttrending', 'tvshows.png', 'DefaultTVShows.png')
		self.addDirectoryItem(60035, 'tvshows&url=traktpopular', 'tvshows.png', 'DefaultTVShows.png', queue=True)
		self.addDirectoryItem(32429, 'tvshows&url=popular', 'tvshows.png', 'DefaultTVShows.png')
		self.addDirectoryItem(32474, 'tvshows&url=active', 'tvshows.png', 'DefaultRecentlyAddedEpisodes.png')
		self.addDirectoryItem(32476, 'tvshows&url=premiere', 'tvshows.png', 'DefaultRecentlyAddedEpisodes.png')
		self.addDirectoryItem(32470, 'tvNetworks', 'networks.png', 'DefaultNetwork.png')
		self.addDirectoryItem(32456, 'tvGenres', 'tvshows.png', 'DefaultGenre.png')
		self.addDirectoryItem(32462, 'tvLanguages', 'tvshows.png', 'DefaultAddonLanguage.png')
		self.addDirectoryItem(32450, 'calendars', 'tvshows.png', 'DefaultYear.png')

		if lite is False:
			if control.getMenuEnabled('mylists.widget'):
				self.addDirectoryItem(60047, 'tvUserlists', 'mytvshows.png', 'DefaultVideoPlaylists.png')

			self.addDirectoryItem(62030, 'tvPerson', 'people-search.png', 'DefaultAddonsSearch.png')
			self.addDirectoryItem(32010, 'tvSearch', 'search.png', 'DefaultAddonsSearch.png')
		self.endDirectory()


	def settings(self):
		#-- General - 0
		self.addDirectoryItem(60001, 'openSettings&query=0.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		#-- Subtitles - 11
		self.addDirectoryItem(60002, 'openSettings&query=11.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		#-- Providers - 4
		self.addDirectoryItem(60003, 'openscrapersSettings&query=0.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(60004, 'urlResolver', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(60018, 'authTrakt&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(60014, 'libraryNavigator', 'tools.png', 'DefaultAddonService.png', isFolder=True)
		if control.condVisibility('System.HasAddon(service.upnext)'):
			self.addDirectoryItem(32505, 'UpNextSettings&query=0.0', 'UpNext.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem(62506, 'contextVenomSettings&query=0.0', 'icon.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem(60015, 'viewsNavigator', 'tools.png', 'DefaultAddonService.png', isFolder=True)
		self.endDirectory()


	def tools(self):
		self.addDirectoryItem(60005, 'clearCache&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(60007, 'clearSources&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(60010, 'clearResolveURLcache', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem(62083, 'cleanSettings', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem(60013, 'clearAllCache&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(60016, 'resetViewTypes', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(62676, 'cleanLibrary', 'tools.png', 'DefaultAddonLibrary.png', isFolder=False)
		self.addDirectoryItem(60006, 'clearMetaCache&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(60011, 'clearCacheSearch&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(60012, 'clearBookmarks&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
#		self.addDirectoryItem(32510, 'cfNavigator', 'tools.png', 'DefaultAddonService.png', isFolder=True)
		self.endDirectory()


	def cf(self):
		self.addDirectoryItem(60006, 'clearMetaCache&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(60011, 'clearCacheSearch&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem(60012, 'clearBookmarks&opensettings=false', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()


	def library(self):
	# -- Library - 9
		self.addDirectoryItem(62557, 'openSettings&query=9.0', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem(62558, 'updateLibrary', 'library_update.png', 'DefaultAddonLibrary.png', isFolder=False)
		self.addDirectoryItem(62676, 'cleanLibrary', 'library_update.png', 'DefaultAddonLibrary.png', isFolder=False)
		self.addDirectoryItem(62559, control.setting('library.movie'), 'movies.png', 'DefaultMovies.png', isAction=False)
		self.addDirectoryItem(62560, control.setting('library.tv'), 'tvshows.png', 'DefaultTVShows.png', isAction=False)

		if traktCredentials is True:
			self.addDirectoryItem(32561, 'moviesToLibrary&url=traktcollection&list_name=traktcollection', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32562, 'moviesToLibrary&url=traktwatchlist&list_name=traktwatchlist', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32672, 'moviesListToLibrary&url=traktlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32673, 'moviesListToLibrary&url=traktlikedlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)

		if tmdbSessionID is True:
			self.addDirectoryItem('TMDb: Import Movie Watchlist...', 'moviesToLibrary&url=tmdb_watchlist&list_name=tmdb_watchlist', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import Movie Favorites...', 'moviesToLibrary&url=tmdb_favorites&list_name=tmdb_favorites', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import Movie User list...', 'moviesListToLibrary&url=tmdb_userlists', 'tmdb.png', 'DefaultMovies.png', isFolder=False)

		if traktCredentials is True:
			self.addDirectoryItem(32563, 'tvshowsToLibrary&url=traktcollection&list_name=traktcollection', 'trakt.png', 'DefaultTVShows.png', isFolder=False)
			self.addDirectoryItem(32564, 'tvshowsToLibrary&url=traktwatchlist&list_name=traktwatchlist', 'trakt.png', 'DefaultTVShows.png', isFolder=False)
			self.addDirectoryItem(32674, 'tvshowsListToLibrary&url=traktlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32675, 'tvshowsListToLibrary&url=traktlikedlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)

		if tmdbSessionID is True:
			self.addDirectoryItem('TMDb: Import TV Watchlist...', 'tvshowsToLibrary&url=tmdb_watchlist&list_name=tmdb_watchlist', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import TV Favorites...', 'tvshowsToLibrary&url=tmdb_favorites&list_name=tmdb_favorites', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import TV User list...', 'tvshowsListToLibrary&url=tmdb_userlists', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
		self.endDirectory()


	def downloads(self):
		movie_downloads = control.setting('movie.download.path')
		tv_downloads = control.setting('tv.download.path')
		if len(control.listDir(movie_downloads)[0]) > 0:
			self.addDirectoryItem(32001, movie_downloads, 'movies.png', 'DefaultMovies.png', isAction=False)
		if len(control.listDir(tv_downloads)[0]) > 0:
			self.addDirectoryItem(32002, tv_downloads, 'tvshows.png', 'DefaultTVShows.png', isAction=False)
		self.endDirectory()


	def search(self):
		self.addDirectoryItem(32001, 'movieSearch', 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(32002, 'tvSearch', 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(62029, 'moviePerson', 'people-search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem(62030, 'tvPerson', 'people-search.png', 'DefaultAddonsSearch.png')
		self.endDirectory()


	def views(self):
		try:
			control.hide()
			items = [ (control.lang(32001).encode('utf-8'), 'movies'), (control.lang(32002).encode('utf-8'), 'tvshows'),
							(control.lang(32054).encode('utf-8'), 'seasons'), (control.lang(32038).encode('utf-8'), 'episodes') ]
			select = control.selectDialog([i[0] for i in items], control.lang(32049).encode('utf-8'))
			if select == -1:
				return
			content = items[select][1]
			title = control.lang(32059).encode('utf-8')
			url = '%s?action=addView&content=%s' % (sys.argv[0], content)
			poster, banner, fanart = control.addonPoster(), control.addonBanner(), control.addonFanart()
			item = control.item(label=title)
			item.setInfo(type='video', infoLabels = {'title': title})
			item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': fanart, 'banner': banner})
			item.setProperty('IsPlayable', 'false')
			control.addItem(handle = int(sys.argv[1]), url=url, listitem=item, isFolder=False)
			control.content(int(sys.argv[1]), content)
			control.directory(int(sys.argv[1]), cacheToDisc=True)
			from resources.lib.modules import views
			views.setView(content, {})
		except:
			log_utils.error()
			return


	def accountCheck(self):
		if traktCredentials is False and imdbCredentials is False:
			control.hide()
			control.notification(title='default', message=32042, icon='WARNING', sound=notificationSound)
			sys.exit()


	def infoCheck(self, version):
		try:
			control.notification(title='default', message=32074, icon='WARNING',  time=5000, sound=notificationSound)
			return '1'
		except:
			return '1'


	def clearCacheAll(self):
		control.hide()
		yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
		if not yes:
			return
		try:
			from resources.lib.modules import cache
			cache.cache_clear_all()
			control.notification(title='default', message='All Cache Successfully Cleared!', icon='default', sound=notificationSound)
		except:
			log_utils.error()
			pass


	def clearCacheProviders(self):
		control.hide()
		yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
		if not yes:
			return
		try:
			from resources.lib.modules import cache
			cache.cache_clear_providers()
			control.notification(title='default', message='Provider Cache Successfully Cleared!', icon='default', sound=notificationSound)
		except:
			log_utils.error()
			pass


	def clearCacheMeta(self):
		control.hide()
		yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
		if not yes:
			return
		try:
			from resources.lib.modules import cache
			cache.cache_clear_meta()
			control.notification(title = 'default', message = 'Metadata Cache Successfully Cleared!', icon = 'default', sound = notificationSound)
		except:
			log_utils.error()
			pass


	def clearCache(self):
		control.hide()
		yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
		if not yes:
			return
		try:
			from resources.lib.modules import cache
			cache.cache_clear()
			control.notification(title = 'default', message = 'Cache Successfully Cleared!', icon = 'default', sound = notificationSound)
		except:
			log_utils.error()
			pass


	def clearCacheSearch(self):
		control.hide()
		yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
		if not yes:
			return
		try:
			from resources.lib.modules import cache
			cache.cache_clear_search()
			control.notification(title = 'default', message = 'Search History Successfully Cleared!', icon = 'default', sound = notificationSound)
		except:
			log_utils.error()
			pass


	def clearCacheSearchPhrase(self, table, name):
		control.hide()
		yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
		if not yes:
			return
		try:
			from resources.lib.modules import cache
			cache.cache_clear_SearchPhrase(table, name)
			control.notification(title = 'default', message = 'Search Phrase Successfully Cleared!', icon = 'default', sound = notificationSound)
		except:
			log_utils.error()
			pass


	def clearBookmarks(self):
		control.hide()
		yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
		if not yes:
			return
		try:
			from resources.lib.modules import cache
			cache.cache_clear_bookmarks()
			control.notification(title = 'default', message = 'Bookmarks Successfully Cleared!', icon = 'default', sound = notificationSound)
		except:
			log_utils.error()
			pass


	def addDirectoryItem(self, name, query, thumb, icon, context=None, queue=False, isAction=True, isFolder=True, isPlayable=False, isSearch=False, table=''):
		try:
			if type(name) is str or type(name) is unicode:
				name = str(name)
			if type(name) is int:
				name = control.lang(name).encode('utf-8')
		except:
			log_utils.error()
		url = '%s?action=%s' % (sysaddon, query) if isAction else query
		thumb = os.path.join(artPath, thumb) if artPath is not None else icon
		if not icon.startswith('Default'):
			icon = os.path.join(artPath, icon)
		cm = []
		queueMenu = control.lang(32065).encode('utf-8')
		if queue is True:
			cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))
		if context is not None:
			cm.append((control.lang(context[0]).encode('utf-8'), 'RunPlugin(%s?action=%s)' % (sysaddon, context[1])))
		if isSearch is True:
			cm.append(('Clear Search Phrase', 'RunPlugin(%s?action=clearSearchPhrase&table=%s&name=%s)' % (sysaddon, table, name)))
		cm.append((control.lang(32610).encode('utf-8'), 'RunPlugin(%s?action=clearAllCache&opensettings=false)' % sysaddon))
		cm.append(('[COLOR red]Venom Settings[/COLOR]', 'RunPlugin(%s?action=openSettings)' % sysaddon))
		item = control.item(label=name)
		item.addContextMenuItems(cm)
		if isPlayable:
			item.setProperty('IsPlayable', 'true')
		else:
			item.setProperty('IsPlayable', 'false')
		item.setArt({'icon': icon, 'poster': thumb, 'thumb': thumb, 'fanart': control.addonFanart(), 'banner': thumb})
		control.addItem(handle=syshandle, url=url, listitem=item, isFolder= isFolder)


	def endDirectory(self):
		control.content(syshandle, 'addons')
		control.directory(syshandle, cacheToDisc=True)