# -*- coding: utf-8 -*-
'''
	Venom Add-on 4.3.52
'''

import sys
from resources.lib.modules import control
from resources.lib.modules import log_utils
from resources.lib.modules import trakt
try: from urllib import quote_plus
except ImportError: from urllib.parse import quote_plus

artPath = control.artPath()
traktCredentials = trakt.getTraktCredentialsInfo()
traktIndicators = trakt.getTraktIndicatorsInfo()
imdbCredentials = control.setting('imdb.user') != ''
tmdbSessionID = control.setting('tmdb.session_id') != ''
indexLabels = control.setting('index.labels') == 'true'
iconLogos = control.setting('icon.logos') != 'Traditional'


class Navigator:
	def root(self):
		self.addDirectoryItem("Movies", 'movieNavigator', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem("TV Shows", 'tvNavigator', 'tvshows.png', 'DefaultTVShows.png')
		self.addDirectoryItem("Originals- Amazon, Hulu, Netflix", 'tvOriginals', 'tvshows.png', 'DefaultTVShows.png')
		if control.getMenuEnabled('navi.prem.services'):
			self.addDirectoryItem("Real-Debrid", 'rd_ServiceNavigator', 'realdebrid.png', 'DefaultAddonService.png')
		self.addDirectoryItem("Search", 'tools_searchNavigator', 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem("Settings", 'tools_toolNavigator', 'tools.png', 'DefaultAddonService.png')
		self.addDirectoryItem("Tools", 'cache_Navigator', 'tools.png', 'DefaultAddonService.png')
		downloads = True if control.setting('downloads') == 'true' and (len(control.listDir(control.setting('movie.download.path'))[0]) > 0 or len(control.listDir(control.setting('tv.download.path'))[0]) > 0) else False
		if downloads:
			self.addDirectoryItem("Downloads", 'downloadNavigator', 'downloads.png', 'DefaultFolder.png')
		self.addDirectoryItem("Version News", 'tools_ShowChangelog', 'icon.png', 'DefaultAddonsUpdates.png', isFolder=False)
		self.endDirectory()


	def movies(self, lite=False):
		self.addDirectoryItem("Trending (Trakt)", 'movies&url=trakttrending', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem("Recently Added (IMDb)", 'movies&url=theaters', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem("Featured (IMDb)", 'movies&url=featured', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem("Most Popular (IMDb)", 'movies&url=mostpopular', 'movies.png', 'DefaultMovies.png')
		self.addDirectoryItem("Genres (IMDb)", 'movieGenres', 'movies.png', 'DefaultGenre.png')
		self.addDirectoryItem("Year (IMDb)", 'movieYears', 'movies.png', 'DefaultYear.png')
		self.addDirectoryItem("People (IMDb)", 'moviePersons', 'movies.png', 'DefaultActor.png')
		self.addDirectoryItem("Search Movies By Actor", 'moviePerson', 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem("Search Movies", 'movieSearch', 'search.png', 'DefaultAddonsSearch.png')
		self.endDirectory()


	def tvshows(self, lite=False):
		self.addDirectoryItem("Trending (Trakt)", 'tvshows&url=trakttrending', 'tvshows.png', 'DefaultTVShows.png')
		self.addDirectoryItem("Most Popular (Trakt)", 'tvshows&url=traktpopular', 'tvshows.png', 'DefaultTVShows.png', queue=True)
		self.addDirectoryItem("Most Popular (IMDb)", 'tvshows&url=popular', 'tvshows.png', 'DefaultTVShows.png')
		self.addDirectoryItem("New TV Shows (IMDb)", 'tvshows&url=premiere', 'tvshows.png', 'DefaultRecentlyAddedEpisodes.png')
		self.addDirectoryItem("Returning TV Shows (IMDb)", 'tvshows&url=active', 'tvshows.png', 'DefaultRecentlyAddedEpisodes.png')
		self.addDirectoryItem("Networks (TVMaze)", 'tvNetworks', 'networks.png', 'DefaultNetwork.png')
		self.addDirectoryItem("Genres (IMDb)", 'tvGenres', 'tvshows.png', 'DefaultGenre.png')
		self.addDirectoryItem("Search TV Shows By Actor", 'tvPerson', 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem("Search TV Shows", 'tvSearch', 'search.png', 'DefaultAddonsSearch.png')
		self.endDirectory()


	def tools(self):
		#-- General - 0
		self.addDirectoryItem("[COLOR lawngreen]Venom Settings[/COLOR]", 'tools_openSettings&query=0.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		#-- Providers - 4
		self.addDirectoryItem("[COLOR lawngreen]FenomScrapers Settings[/COLOR]", 'tools_fenomscrapersSettings', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]My Accounts Settings[/COLOR]", 'tools_openMyAccount', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		#-- Subtitles - 11
		self.addDirectoryItem("[COLOR lawngreen]Subtitle Settings[/COLOR]", 'tools_openSettings&query=11.0', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Manage Library[/COLOR]", 'library_Navigator', 'tools.png', 'DefaultAddonService.png', isFolder=True)
		if control.condVisibility('System.HasAddon(service.upnext)'):
			self.addDirectoryItem("[COLOR lawngreen]UpNext Settings[/COLOR]", 'tools_UpNextSettings', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Set View Types[/COLOR]", 'tools_viewsNavigator', 'tools.png', 'DefaultAddonService.png', isFolder=True)
		self.endDirectory()


	def cf(self):
		self.addDirectoryItem("[COLOR lawngreen]Clear Cache[/COLOR]", 'cache_clearCache', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Clear Providers-Scrapers Cache[/COLOR]", 'cache_clearSources', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Clear Metadata Cache[/COLOR]", 'cache_clearMeta', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Clear Search Cache[/COLOR]", 'cache_clearSearch', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Clear Bookmarks Cache[/COLOR]", 'cache_clearBookmarks', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Clear ALL Cache[/COLOR]", 'cache_clearAll', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Clean Settings[/COLOR]", 'tools_cleanSettings', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem("[COLOR lawngreen]Reset View Types[/COLOR]", 'tools_resetViewTypes', 'tools.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()


	def library(self):
	# -- Library - 9
		self.addDirectoryItem("Library Settings", 'tools_openSettings&query=9.0', 'tools.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem("Update library", 'library_update', 'library_update.png', 'DefaultAddonLibrary.png', isFolder=False)
		self.addDirectoryItem("Clean library", 'library_clean', 'library_update.png', 'DefaultAddonLibrary.png', isFolder=False)
		self.addDirectoryItem("Movie folder", control.setting('library.movie'), 'movies.png', 'DefaultMovies.png', isAction=False)
		self.addDirectoryItem("TV folder", control.setting('library.tv'), 'tvshows.png', 'DefaultTVShows.png', isAction=False)
		if traktCredentials:
			self.addDirectoryItem(32561, 'library_moviesToLibrary&url=traktcollection&name=traktcollection', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32562, 'library_moviesToLibrary&url=traktwatchlist&name=traktwatchlist', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32672, 'library_moviesListToLibrary&url=traktlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32673, 'library_moviesListToLibrary&url=traktlikedlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
		if tmdbSessionID:
			self.addDirectoryItem('TMDb: Import Movie Watchlist...', 'library_moviesToLibrary&url=tmdb_watchlist&name=tmdb_watchlist', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import Movie Favorites...', 'library_moviesToLibrary&url=tmdb_favorites&name=tmdb_favorites', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import Movie User list...', 'library_moviesListToLibrary&url=tmdb_userlists', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
		if traktCredentials:
			self.addDirectoryItem(32563, 'library_tvshowsToLibrary&url=traktcollection&name=traktcollection', 'trakt.png', 'DefaultTVShows.png', isFolder=False)
			self.addDirectoryItem(32564, 'library_tvshowsToLibrary&url=traktwatchlist&name=traktwatchlist', 'trakt.png', 'DefaultTVShows.png', isFolder=False)
			self.addDirectoryItem(32674, 'library_tvshowsListToLibrary&url=traktlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem(32675, 'library_tvshowsListToLibrary&url=traktlikedlists', 'trakt.png', 'DefaultMovies.png', isFolder=False)
		if tmdbSessionID:
			self.addDirectoryItem('TMDb: Import TV Watchlist...', 'library_tvshowsToLibrary&url=tmdb_watchlist&name=tmdb_watchlist', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import TV Favorites...', 'library_tvshowsToLibrary&url=tmdb_favorites&name=tmdb_favorites', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
			self.addDirectoryItem('TMDb: Import TV User list...', 'library_tvshowsListToLibrary&url=tmdb_userlists', 'tmdb.png', 'DefaultMovies.png', isFolder=False)
		self.endDirectory()


	def downloads(self):
		movie_downloads = control.setting('movie.download.path')
		tv_downloads = control.setting('tv.download.path')
		if len(control.listDir(movie_downloads)[0]) > 0:
			self.addDirectoryItem(32001, movie_downloads, 'movies.png', 'DefaultMovies.png', isAction=False)
		if len(control.listDir(tv_downloads)[0]) > 0:
			self.addDirectoryItem(32002, tv_downloads, 'tvshows.png', 'DefaultTVShows.png', isAction=False)
		self.endDirectory()


	def premium_services(self):
		self.addDirectoryItem(40059, 'ad_ServiceNavigator', 'alldebrid.png', 'DefaultAddonService.png')
		self.addDirectoryItem(40057, 'pm_ServiceNavigator', 'premiumize.png', 'DefaultAddonService.png')
		self.addDirectoryItem(40058, 'rd_ServiceNavigator', 'realdebrid.png', 'DefaultAddonService.png')
		self.endDirectory()


	def alldebrid_service(self):
		if control.setting('alldebrid.token'):
			self.addDirectoryItem('All-Debrid: Cloud Storage', 'ad_CloudStorage', 'alldebrid.png', 'DefaultAddonService.png')
			self.addDirectoryItem('All-Debrid: Transfers', 'ad_Transfers', 'alldebrid.png', 'DefaultAddonService.png')
			self.addDirectoryItem('All-Debrid: Account Info', 'ad_AccountInfo', 'alldebrid.png', 'DefaultAddonService.png', isFolder=False)
		else:
			self.addDirectoryItem('[I]Please visit My Accounts for setup[/I]', 'tools_openMyAccount&amp;query=1.4', 'alldebrid.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()


	def premiumize_service(self):
		if control.setting('premiumize.token'):
			self.addDirectoryItem('Premiumize: My Files', 'pm_MyFiles', 'premiumize.png', 'DefaultAddonService.png')
			self.addDirectoryItem('Premiumize: Transfers', 'pm_Transfers', 'premiumize.png', 'DefaultAddonService.png')
			self.addDirectoryItem('Premiumize: Account Info', 'pm_AccountInfo', 'premiumize.png', 'DefaultAddonService.png', isFolder=False)
		else:
			self.addDirectoryItem('[I]Please visit My Accounts for setup[/I]', 'tools_openMyAccount&amp;query=1.11', 'premiumize.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()


	def realdebrid_service(self):
		if control.setting('realdebrid.token'):
			self.addDirectoryItem('Real-Debrid: Torrent Transfers', 'rd_UserTorrentsToListItem', 'realdebrid.png', 'DefaultAddonService.png')
			self.addDirectoryItem('Real-Debrid: My Downloads', 'rd_MyDownloads&query=1', 'realdebrid.png', 'DefaultAddonService.png')
			self.addDirectoryItem('Real-Debrid: Account Info', 'rd_AccountInfo', 'realdebrid.png', 'DefaultAddonService.png',isFolder=False )
		else:
			self.addDirectoryItem('[I]Please visit My Accounts for setup[/I]', 'tools_openMyAccount&amp;query=1.18', 'realdebrid.png', 'DefaultAddonService.png', isFolder=False)
		self.endDirectory()


	def search(self):
		self.addDirectoryItem("Search Movies", 'movieSearch', 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem("Search TV Shows", 'tvSearch', 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem("Search Movies By Actor", 'moviePerson', 'search.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem("Search TV Shows By Actor", 'tvPerson', 'search.png', 'DefaultAddonsSearch.png')
		self.endDirectory()


	def views(self):
		try:
			control.hide()
			items = [ (control.lang(32001), 'movies'), (control.lang(32002), 'tvshows'),
							(control.lang(32054), 'seasons'), (control.lang(32038), 'episodes') ]
			select = control.selectDialog([i[0] for i in items], control.lang(32049))
			if select == -1: return
			content = items[select][1]
			title = control.lang(32059)
			url = '%s?action=tools_addView&content=%s' % (sys.argv[0], content)
			poster, banner, fanart = control.addonPoster(), control.addonBanner(), control.addonFanart()
			item = control.item(label=title)
			item.setInfo(type='video', infoLabels = {'title': title})
			item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': fanart, 'banner': banner})
			item.setProperty('IsPlayable', 'false')
			control.addItem(handle = int(sys.argv[1]), url=url, listitem=item, isFolder=False)
			control.content(int(sys.argv[1]), content)
			control.directory(int(sys.argv[1]), cacheToDisc=True)
			from resources.lib.modules import views
			views.setView(content, {})
		except:
			log_utils.error()
			return


	def accountCheck(self):
		if not traktCredentials and not imdbCredentials:
			control.hide()
			control.notification(message=32042, icon='WARNING')
			sys.exit()


	def clearCacheAll(self):
		control.hide()
		if not control.yesnoDialog(control.lang(32077), '', ''): return
		try:
			from resources.lib.modules import cache
			if cache.cache_clear_all():
				control.notification(message=32089)
			else: control.notification(message=33586)
		except:
			log_utils.error()


	def clearCacheProviders(self):
		control.hide()
		if not control.yesnoDialog(control.lang(32056), '', ''): return
		try:
			from resources.lib.modules import cache
			if cache.cache_clear_providers():
				control.notification(message=32090)
			else: control.notification(message=33586)
		except:
			log_utils.error()


	def clearCacheMeta(self):
		control.hide()
		if not control.yesnoDialog(control.lang(32076), '', ''): return
		try:
			from resources.lib.modules import cache
			if cache.cache_clear_meta():
				control.notification(message=32091)
			else: control.notification(message=33586)
		except:
			log_utils.error()


	def clearCache(self):
		control.hide()
		if not control.yesnoDialog(control.lang(32056), '', ''): return
		try:
			from resources.lib.modules import cache
			if cache.cache_clear():
				control.notification(message=32092)
			else: control.notification(message=33586)
		except:
			log_utils.error()


	def clearCacheSearch(self):
		control.hide()
		if not control.yesnoDialog(control.lang(32056), '', ''): return
		try:
			from resources.lib.modules import cache
			if cache.cache_clear_search():
				control.notification(message=32093)
			else: control.notification(message=33586)
		except:
			log_utils.error()


	def clearCacheSearchPhrase(self, table, name):
		control.hide()
		if not control.yesnoDialog(control.lang(32056), '', ''): return
		try:
			from resources.lib.modules import cache
			if cache.cache_clear_SearchPhrase(table, name):
				control.notification(message=32094)
			else: control.notification(message=33586)
		except:
			log_utils.error()


	def clearBookmarks(self):
		control.hide()
		if not control.yesnoDialog(control.lang(32056), '', ''): return
		try:
			from resources.lib.modules import cache
			if cache.cache_clear_bookmarks():
				control.notification(message=32100)
			else: control.notification(message=33586)
		except:
			log_utils.error()


	def clearBookmark(self, name, year):
		control.hide()
		if not control.yesnoDialog(control.lang(32056), '', ''): return
		try:
			from resources.lib.modules import cache
			if cache.cache_clear_bookmark(name, year):
				control.notification(title=name, message=32102)
			else: control.notification(message=33586)
		except:
			log_utils.error()


	def addDirectoryItem(self, name, query, thumb, icon, context=None, queue=False, isAction=True, isFolder=True, isPlayable=False, isSearch=False, table=''):
		sysaddon = sys.argv[0]
		syshandle = int(sys.argv[1])
		try:
			if type(name) is str or type(name) is unicode: name = str(name)
			if type(name) is int: name = control.lang(name)
		except:
			log_utils.error()

		url = '%s?action=%s' % (sysaddon, query) if isAction else query
		thumb = control.joinPath(artPath, thumb) if artPath else icon
		if not icon.startswith('Default'):
			icon = control.joinPath(artPath, icon)
		cm = []
		queueMenu = control.lang(32065)
		if queue:
			cm.append((queueMenu, 'RunPlugin(%s?action=playlist_QueueItem)' % sysaddon))
		if context:
			cm.append((control.lang(context[0]), 'RunPlugin(%s?action=%s)' % (sysaddon, context[1])))
		if isSearch:
			cm.append(('Clear Search Phrase', 'RunPlugin(%s?action=cache_clearSearchPhrase&source=%s&name=%s)' % (sysaddon, table, quote_plus(name))))
		cm.append(('[COLOR red]Venom Settings[/COLOR]', 'RunPlugin(%s?action=tools_openSettings)' % sysaddon))
		item = control.item(label=name)
		item.addContextMenuItems(cm)
		if isPlayable: item.setProperty('IsPlayable', 'true')
		else: item.setProperty('IsPlayable', 'false')
		item.setArt({'icon': icon, 'poster': thumb, 'thumb': thumb, 'fanart': control.addonFanart(), 'banner': thumb})
		control.addItem(handle=syshandle, url=url, listitem=item, isFolder= isFolder)


	def endDirectory(self):
		syshandle = int(sys.argv[1])
		control.content(syshandle, 'addons')
		control.directory(syshandle, cacheToDisc=True)